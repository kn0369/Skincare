from read import read_products
from write import write_products
from operations import (display_products, sell_products, restock_products, 
                      ALL_TRANSACTIONS)

def main():
    filename = 'productss.txt'
    products = read_products(filename)

    while True:
        print("\nWeCare Beauty Products Management System")
        print("1. Sell Products")
        print("2. Restock Products")
        print("3. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            if products:
                cart = sell_products(products)
                if cart:
                    for item in cart:
                        product = item['product']
                        total_deduct = item['quantity'] + item['free_items']
                        product['Quantity'] -= total_deduct
                    write_products(filename, products)
            else:
                print("No products available to sell.")
        elif choice == '2':
            restock_items = restock_products(products)
            if restock_items:
                for item in restock_items:
                    product = item['product']
                    product['Quantity'] += item['quantity']
                    product['Cost Price'] = item['cost_price']
                write_products(filename, products)
        elif choice == '3':
            print("Exiting system. Goodbye!")
            break
        else:
            print("Invalid choice! Please try again.")

if __name__ == "__main__":
    main()
