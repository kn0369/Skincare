import datetime

ALL_TRANSACTIONS = []

def display_products(products):
    """Display all products in a formatted table"""
    print("\nAvailable Products:")
    print(f"{'ID':<4}{'Name':<25}{'Brand':<15}{'Qty':<6}{'Sell Price':<12}{'Cost Price':<12}{'Country':<15}")
    print("-" * 95)
    for i, p in enumerate(products, 1):
        sell_price = p['Cost Price'] * 2
        print(f"{i:<4}{p['Name'][:24]:<25}{p['Brand'][:14]:<15}{p['Quantity']:<6}${sell_price:<11}${p['Cost Price']:<11}{p['Country'][:14]:<15}")

def calculate_free_items(quantity):
    """Calculate free items based on buy 3 get 1 free policy"""
    return quantity // 3

def sell_products(products):
    """Handle product selling process"""
    cart = []
    customer_name = input("Enter customer name: ")
    display_products(products)

    while True:
        try:
            product_id = int(input("\nEnter product ID to add to cart (0 to finish): "))
            if product_id == 0:
                break
            if product_id < 1 or product_id > len(products):
                print("Invalid product ID!")
                continue

            product = products[product_id - 1]
            max_quantity = product['Quantity']
            quantity = int(input(f"Enter quantity (available: {max_quantity}): "))

            if quantity <= 0:
                print("Quantity must be positive!")
                continue

            free_items = calculate_free_items(quantity)
            total_items_needed = quantity + free_items

            if total_items_needed > max_quantity:
                print(f"Not enough stock! You need {total_items_needed}, but only {max_quantity} available.")
                continue

            cart.append({
                'product': product,
                'quantity': quantity,
                'free_items': free_items
            })

            print(f"Added {quantity} {product['Name']} to cart ({free_items} free).")

        except ValueError:
            print("Invalid input! Please enter numbers only.")

    if not cart:
        print("No items in cart. Transaction cancelled.")
        return None

    generate_sales_invoice(cart, customer_name)
    return cart

def generate_sales_invoice(cart, customer_name):
    """Generate and display sales invoice"""
    total_amount = 0
    invoice_lines = []
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")

    invoice_lines.append("\n" + "=" * 80)
    invoice_lines.append("WE CARE BEAUTY STORE - SALES INVOICE")
    invoice_lines.append("=" * 80)
    invoice_lines.append(f"Date: {timestamp}")
    invoice_lines.append(f"Customer: {customer_name}")
    invoice_lines.append("-" * 80)
    invoice_lines.append(f"{'Product':<25}{'Brand':<15}{'Qty':<5}{'Free':<6}{'Sell':<10}{'Subtotal':<10}")
    invoice_lines.append("-" * 80)

    for item in cart:
        product = item['product']
        qty = item['quantity']
        free = item['free_items']
        sell_price = product['Cost Price'] * 2
        subtotal = qty * sell_price
        total_amount += subtotal

        invoice_lines.append(
            f"{product['Name'][:24]:<25}{product['Brand'][:14]:<15}{qty:<5}{free:<6}${sell_price:<9}${subtotal:<10}"
        )

    invoice_lines.append("-" * 80)
    invoice_lines.append(f"{'TOTAL':<68}${total_amount}")
    invoice_lines.append("=" * 80)
    invoice_lines.append("** Buy 3 Get 1 Free Policy Applied **")
    invoice_lines.append(f"Invoice generated at: {timestamp}")
    invoice_lines.append("=" * 80)

    ALL_TRANSACTIONS.append("\n".join(invoice_lines))
    print("\n" + "\n".join(invoice_lines))

def restock_products(products):
    """Handle product restocking process"""
    restock_items = []
    supplier_name = input("Enter supplier name: ")
    display_products(products)

    while True:
        try:
            product_id = input("\nEnter product ID to restock (or 'new' to add a new product, 0 to finish): ")
            
            if product_id == '0':
                break
            
            if product_id.lower() == 'new':
                new_product = {
                    'Name': input("Enter product name: "),
                    'Brand': input("Enter product brand: "),
                    'Quantity': int(input("Enter initial quantity: ")),
                    'Cost Price': int(input("Enter initial cost price: ")),
                    'Country': input("Enter product country: ")
                }
                products.append(new_product)
                print(f"{new_product['Name']} has been added")
                display_products(products)
                continue
            
            product_id = int(product_id)
            if product_id < 1 or product_id > len(products):
                print("Invalid product ID!")
                continue

            product = products[product_id - 1]
            print(f"Current stock: {product['Quantity']}")

            quantity = int(input("Enter quantity to add: "))
            if quantity <= 0:
                print("Quantity must be positive!")
                continue

            new_cost = input(f"Enter new cost price (current: {product['Cost Price']}, press Enter to keep): ")
            cost_price = int(new_cost) if new_cost else product['Cost Price']

            restock_items.append({
                'product': product,
                'quantity': quantity,
                'cost_price': cost_price
            })

            print(f"Added {quantity} {product['Name']} to restock list.")

        except ValueError:
            print("Invalid input! Please enter numbers only.")

    if not restock_items:
        print("No items to restock. Transaction cancelled.")
        return None

    generate_restock_invoice(restock_items, supplier_name)
    return restock_items

def generate_restock_invoice(restock_items, supplier_name):
    """Generate and display restock invoice"""
    total_amount = 0
    invoice_lines = []
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")

    invoice_lines.append("\n" + "=" * 80)
    invoice_lines.append("WE CARE BEAUTY STORE - RESTOCK RECEIPT")
    invoice_lines.append("=" * 80)
    invoice_lines.append(f"Date: {timestamp}")
    invoice_lines.append(f"Supplier: {supplier_name}")
    invoice_lines.append("-" * 80)
    invoice_lines.append(f"{'Product':<25}{'Brand':<15}{'Qty':<6}{'Cost':<10}{'Subtotal':<10}")
    invoice_lines.append("-" * 80)

    for item in restock_items:
        product = item['product']
        qty = item['quantity']
        cost = item['cost_price']
        subtotal = qty * cost
        total_amount += subtotal

        invoice_lines.append(
            f"{product['Name'][:24]:<25}{product['Brand'][:14]:<15}{qty:<6}${cost:<9}${subtotal:<10}"
        )

    invoice_lines.append("-" * 80)
    invoice_lines.append(f"{'TOTAL':<68}${total_amount}")
    invoice_lines.append("=" * 80)
    invoice_lines.append(f"Restocked at: {timestamp}")
    invoice_lines.append("=" * 80)

    ALL_TRANSACTIONS.append("\n".join(invoice_lines))
    print("\n" + "\n".join(invoice_lines))
