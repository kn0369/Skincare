import os

def read_products(filename):
    """Read products from file and return as list of dictionaries"""
    products = []
    if not os.path.exists(filename):
        return products

    with open(filename, 'r') as file:
        for line in file:
            parts = line.strip().split(", ")
            if len(parts) >= 5:
                product = {
                    'ID': len(products) + 1,
                    'Name': parts[0],
                    'Brand': parts[1],
                    'Quantity': int(parts[2]),
                    'Cost Price': int(parts[3]),
                    'Country': parts[4],
                    'Original Quantity': int(parts[2])
                }
                products.append(product)
    return products
