def write_products(filename, products):
    """Write products to file"""
    with open(filename, 'w') as file:
        for product in products:
            line = f"{product['Name']}, {product['Brand']}, {product['Quantity']}, {product['Cost Price']}, {product['Country']}\n"
            file.write(line)
